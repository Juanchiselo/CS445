package Program01;

public class Primitive 
{
    private String type;
    
    public Primitive(String type)
    {
        this.type = type;
    }
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
